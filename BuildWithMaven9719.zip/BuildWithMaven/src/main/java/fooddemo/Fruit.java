package fooddemo;

public class Fruit {
	public String talkAboutYourself() {
		return "Hi I am a fruit. I come from plants or trees with seeds.";
	}

}
