package fooddemo;

public class HelloFood {

	public static void main(String[] args) {


		Fruit f = new Fruit();
		Vegetable v = new Vegetable();
		
		System.out.println(f.talkAboutYourself());
		
		System.out.println(v.talkAboutYourself());
	}

}
