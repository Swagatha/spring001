package fooddemo;

public class Vegetable {
	public String talkAboutYourself() {
		return "Hi I am a vegetable. I am a plant that is eaten as food.";
	}


}
