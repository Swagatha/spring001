package swat.chat.io.justgifit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JustGifItApplicationTests {

	@Test
	void contextLoads() {
	}

}
